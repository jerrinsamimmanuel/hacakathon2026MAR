import { createContext, useContext } from "react";
import { AITool } from "./types";

export interface AppState {
  tools: AITool[];
  searchQuery: string;
  isDark: boolean;
}

export interface AppContextType {
  state: AppState;
  toggleFavorite: (id: string) => void;
  addTool: (tool: Omit<AITool, "id" | "rating" | "totalRatings" | "views" | "isFavorite" | "createdAt">) => void;
  rateTool: (id: string, rating: number) => void;
  viewTool: (id: string) => void;
  setSearchQuery: (q: string) => void;
  toggleDarkMode: () => void;
  getFilteredTools: (query?: string) => AITool[];
}

export const AppContext = createContext<AppContextType | null>(null);

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
