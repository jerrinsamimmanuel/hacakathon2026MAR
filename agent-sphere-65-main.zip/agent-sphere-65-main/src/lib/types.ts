export interface AITool {
  id: string;
  name: string;
  url: string;
  description: string;
  category: AICategory;
  author: string; // who created the AI tool
  addedBy: string; // who added it to marketplace
  rating: number;
  totalRatings: number;
  views: number;
  isFavorite: boolean;
  createdAt: string;
  emoji: string;
  imageUrl?: string;
}

// Semantic keyword mappings for smart search
export const SEMANTIC_KEYWORDS: Record<string, string[]> = {
  "story": ["writing", "chatgpt", "jasper", "copy.ai", "essay", "article", "narrative"],
  "stories": ["writing", "chatgpt", "jasper", "copy.ai", "essay", "article", "narrative"],
  "essay": ["writing", "chatgpt", "jasper", "grammarly", "article"],
  "calculate": ["coding", "deepseek", "chatgpt", "copilot", "math", "computation"],
  "calculation": ["coding", "deepseek", "chatgpt", "copilot", "math"],
  "math": ["coding", "deepseek", "chatgpt", "calculation"],
  "draw": ["image generation", "dall·e", "midjourney", "stable diffusion", "leonardo"],
  "picture": ["image generation", "dall·e", "midjourney", "stable diffusion", "leonardo"],
  "photo": ["image generation", "dall·e", "midjourney", "stable diffusion"],
  "art": ["image generation", "midjourney", "dall·e", "leonardo"],
  "paint": ["image generation", "midjourney", "dall·e", "stable diffusion"],
  "slide": ["ppt creation", "beautiful.ai", "tome", "gamma", "presentation"],
  "slides": ["ppt creation", "beautiful.ai", "tome", "gamma", "presentation"],
  "presentation": ["ppt creation", "beautiful.ai", "tome", "gamma", "microsoft copilot"],
  "ppt": ["ppt creation", "beautiful.ai", "tome", "gamma"],
  "website": ["website creation", "wix", "framer", "durable", "10web"],
  "web": ["website creation", "wix", "framer", "durable", "10web", "coding"],
  "site": ["website creation", "wix", "framer", "durable"],
  "code": ["coding", "github copilot", "cursor", "replit", "programming"],
  "program": ["coding", "github copilot", "cursor", "replit"],
  "programming": ["coding", "github copilot", "cursor", "replit"],
  "debug": ["coding", "github copilot", "cursor", "chatgpt"],
  "song": ["music creation", "suno", "udio", "aiva"],
  "music": ["music creation", "suno", "udio", "aiva"],
  "sing": ["music creation", "suno", "udio"],
  "video": ["video creation", "synthesia", "runway", "pictory"],
  "movie": ["video creation", "synthesia", "runway", "pictory"],
  "film": ["video creation", "synthesia", "runway"],
  "edit": ["video creation", "runway", "coding", "cursor"],
  "write": ["writing", "chatgpt", "jasper", "copy.ai", "grammarly"],
  "blog": ["writing", "jasper", "copy.ai", "chatgpt"],
  "email": ["writing", "jasper", "copy.ai", "grammarly"],
  "grammar": ["writing", "grammarly", "chatgpt"],
  "chat": ["writing", "chatgpt", "conversation"],
  "talk": ["writing", "chatgpt"],
  "logo": ["image generation", "dall·e", "midjourney", "leonardo"],
  "design": ["image generation", "website creation", "framer", "midjourney"],
  "ai": ["chatgpt", "copilot", "midjourney", "dall·e"],
};

export type AICategory =
  | "PPT Creation"
  | "Website Creation"
  | "Writing"
  | "Image Generation"
  | "Video Creation"
  | "Coding"
  | "Music Creation";

export const CATEGORY_INFO: Record<AICategory, { emoji: string; description: string }> = {
  "PPT Creation": { emoji: "📊", description: "Creates PowerPoint slides automatically from a topic or text" },
  "Website Creation": { emoji: "🌐", description: "Creates websites automatically using AI" },
  "Writing": { emoji: "✍️", description: "Helps write essays, passages, articles, and stories" },
  "Image Generation": { emoji: "🎨", description: "Creates images from text prompts" },
  "Video Creation": { emoji: "🎬", description: "Creates videos automatically from text or scripts" },
  "Coding": { emoji: "💻", description: "Helps write, debug, and generate code" },
  "Music Creation": { emoji: "🎵", description: "Creates music and audio from text or prompts" },
};

export const ALL_CATEGORIES: AICategory[] = [
  "PPT Creation",
  "Website Creation",
  "Writing",
  "Image Generation",
  "Video Creation",
  "Coding",
  "Music Creation",
];
