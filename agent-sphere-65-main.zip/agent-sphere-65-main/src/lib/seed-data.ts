import { AITool } from "./types";

export const seedTools: AITool[] = [
  // PPT Creation
  { id: "1", name: "Beautiful.ai", url: "https://beautiful.ai", description: "AI-powered presentations that design themselves. Just add content and Beautiful.ai creates stunning slides.", category: "PPT Creation", author: "Beautiful.ai Team", addedBy: "Admin", rating: 4.2, totalRatings: 340, views: 8200, isFavorite: false, createdAt: "2024-01-15", emoji: "📊" },
  { id: "2", name: "Tome", url: "https://tome.app", description: "AI-native storytelling format. Create compelling narratives with AI-generated text and images.", category: "PPT Creation", author: "Tome Inc.", addedBy: "Admin", rating: 4.5, totalRatings: 520, views: 12400, isFavorite: false, createdAt: "2024-01-10", emoji: "📊" },
  { id: "3", name: "Gamma", url: "https://gamma.app", description: "A new medium for presenting ideas powered by AI. No more slide decks — just beautiful content.", category: "PPT Creation", author: "Gamma Team", addedBy: "Admin", rating: 4.7, totalRatings: 680, views: 15600, isFavorite: false, createdAt: "2024-02-01", emoji: "📊" },
  { id: "4", name: "Microsoft Copilot", url: "https://copilot.microsoft.com", description: "AI assistant integrated into PowerPoint for creating presentations from prompts.", category: "PPT Creation", author: "Microsoft", addedBy: "Admin", rating: 4.3, totalRatings: 890, views: 22000, isFavorite: false, createdAt: "2024-01-05", emoji: "📊" },

  // Website Creation
  { id: "5", name: "Wix ADI", url: "https://wix.com", description: "Artificial Design Intelligence creates a stunning website for you in minutes.", category: "Website Creation", author: "Wix", addedBy: "Admin", rating: 4.0, totalRatings: 1200, views: 35000, isFavorite: false, createdAt: "2024-01-20", emoji: "🌐" },
  { id: "6", name: "Framer AI", url: "https://framer.com", description: "Design and publish stunning sites with AI. Start with a prompt and customize everything.", category: "Website Creation", author: "Framer", addedBy: "Admin", rating: 4.6, totalRatings: 780, views: 19500, isFavorite: false, createdAt: "2024-02-10", emoji: "🌐" },
  { id: "7", name: "Durable", url: "https://durable.co", description: "Build a website in 30 seconds with AI. The world's fastest website builder.", category: "Website Creation", author: "Durable Inc.", addedBy: "Admin", rating: 4.1, totalRatings: 420, views: 9800, isFavorite: false, createdAt: "2024-03-01", emoji: "🌐" },
  { id: "8", name: "10Web", url: "https://10web.io", description: "AI-powered WordPress platform. Build, host, and manage websites with AI.", category: "Website Creation", author: "10Web", addedBy: "Admin", rating: 3.9, totalRatings: 310, views: 7600, isFavorite: false, createdAt: "2024-02-15", emoji: "🌐" },

  // Writing
  { id: "9", name: "ChatGPT", url: "https://chat.openai.com", description: "Advanced AI chatbot that writes essays, stories, articles, code, and more with human-like quality.", category: "Writing", author: "OpenAI", addedBy: "Admin", rating: 4.8, totalRatings: 5000, views: 150000, isFavorite: false, createdAt: "2024-01-01", emoji: "✍️" },
  { id: "10", name: "Jasper AI", url: "https://jasper.ai", description: "AI content platform for marketing teams. Create blog posts, ads, emails, and more.", category: "Writing", author: "Jasper", addedBy: "Admin", rating: 4.4, totalRatings: 920, views: 28000, isFavorite: false, createdAt: "2024-01-12", emoji: "✍️" },
  { id: "11", name: "Copy.ai", url: "https://copy.ai", description: "AI-powered copywriter that generates marketing copy, blog content, and social media posts.", category: "Writing", author: "Copy.ai Inc.", addedBy: "Admin", rating: 4.2, totalRatings: 650, views: 18000, isFavorite: false, createdAt: "2024-01-18", emoji: "✍️" },
  { id: "12", name: "Grammarly", url: "https://grammarly.com", description: "AI writing assistant that checks grammar, style, tone, and helps rewrite text.", category: "Writing", author: "Grammarly Inc.", addedBy: "Admin", rating: 4.6, totalRatings: 3200, views: 95000, isFavorite: false, createdAt: "2024-01-02", emoji: "✍️" },

  // Image Generation
  { id: "13", name: "DALL·E", url: "https://openai.com/dall-e", description: "Creates realistic images and art from natural language descriptions.", category: "Image Generation", author: "OpenAI", addedBy: "Admin", rating: 4.7, totalRatings: 4200, views: 120000, isFavorite: false, createdAt: "2024-01-03", emoji: "🎨" },
  { id: "14", name: "Midjourney", url: "https://midjourney.com", description: "AI art generator that creates stunning, artistic images from text prompts.", category: "Image Generation", author: "Midjourney Inc.", addedBy: "Admin", rating: 4.9, totalRatings: 6800, views: 180000, isFavorite: false, createdAt: "2024-01-01", emoji: "🎨" },
  { id: "15", name: "Stable Diffusion", url: "https://stability.ai", description: "Open-source AI image generation model. Create any image you can imagine.", category: "Image Generation", author: "Stability AI", addedBy: "Admin", rating: 4.5, totalRatings: 3100, views: 85000, isFavorite: false, createdAt: "2024-01-06", emoji: "🎨" },
  { id: "16", name: "Leonardo AI", url: "https://leonardo.ai", description: "Create production-quality visual assets for your projects with AI-driven speed.", category: "Image Generation", author: "Leonardo AI", addedBy: "Admin", rating: 4.4, totalRatings: 1800, views: 45000, isFavorite: false, createdAt: "2024-02-05", emoji: "🎨" },

  // Video Creation
  { id: "17", name: "Synthesia", url: "https://synthesia.io", description: "Create AI videos with AI avatars. Turn text into professional videos in minutes.", category: "Video Creation", author: "Synthesia", addedBy: "Admin", rating: 4.5, totalRatings: 1500, views: 42000, isFavorite: false, createdAt: "2024-01-08", emoji: "🎬" },
  { id: "18", name: "Runway", url: "https://runway.ml", description: "AI-powered creative tools for video editing, generation, and visual effects.", category: "Video Creation", author: "Runway AI", addedBy: "Admin", rating: 4.6, totalRatings: 2100, views: 58000, isFavorite: false, createdAt: "2024-01-04", emoji: "🎬" },
  { id: "19", name: "Pictory", url: "https://pictory.ai", description: "Create short branded videos from long-form content using AI.", category: "Video Creation", author: "Pictory", addedBy: "Admin", rating: 4.1, totalRatings: 680, views: 16000, isFavorite: false, createdAt: "2024-02-20", emoji: "🎬" },

  // Coding
  { id: "20", name: "GitHub Copilot", url: "https://github.com/features/copilot", description: "AI pair programmer that suggests code completions in real-time.", category: "Coding", author: "GitHub / OpenAI", addedBy: "Admin", rating: 4.7, totalRatings: 4500, views: 130000, isFavorite: false, createdAt: "2024-01-01", emoji: "💻" },
  { id: "21", name: "Cursor", url: "https://cursor.sh", description: "The AI-first code editor. Write, edit, and understand code with AI.", category: "Coding", author: "Cursor Inc.", addedBy: "Admin", rating: 4.8, totalRatings: 2800, views: 75000, isFavorite: false, createdAt: "2024-01-15", emoji: "💻" },
  { id: "22", name: "Replit AI", url: "https://replit.com", description: "AI-powered coding platform. Build, deploy, and collaborate on software.", category: "Coding", author: "Replit", addedBy: "Admin", rating: 4.3, totalRatings: 1900, views: 52000, isFavorite: false, createdAt: "2024-01-20", emoji: "💻" },

  // Music Creation
  { id: "23", name: "Suno", url: "https://suno.com", description: "Create music with AI. Generate full songs with vocals, instruments, and lyrics.", category: "Music Creation", author: "Suno Inc.", addedBy: "Admin", rating: 4.6, totalRatings: 2200, views: 62000, isFavorite: false, createdAt: "2024-02-01", emoji: "🎵" },
  { id: "24", name: "Udio", url: "https://udio.com", description: "AI music generation platform. Create professional-quality music from text.", category: "Music Creation", author: "Udio", addedBy: "Admin", rating: 4.5, totalRatings: 1600, views: 38000, isFavorite: false, createdAt: "2024-03-01", emoji: "🎵" },
  { id: "25", name: "AIVA", url: "https://aiva.ai", description: "AI music composition assistant. Create emotional soundtrack music.", category: "Music Creation", author: "AIVA Technologies", addedBy: "Admin", rating: 4.2, totalRatings: 780, views: 19000, isFavorite: false, createdAt: "2024-01-25", emoji: "🎵" },
];
