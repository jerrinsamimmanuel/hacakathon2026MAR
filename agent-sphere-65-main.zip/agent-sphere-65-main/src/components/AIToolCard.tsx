import { Heart, Star, Eye, ExternalLink } from "lucide-react";
import { AITool } from "@/lib/types";
import { useApp } from "@/lib/store";
import { useState } from "react";
import { motion } from "framer-motion";

interface Props {
  tool: AITool;
  rank?: number;
}

export default function AIToolCard({ tool, rank }: Props) {
  const { toggleFavorite, rateTool, viewTool } = useApp();
  const [showRating, setShowRating] = useState(false);
  const [hoverStar, setHoverStar] = useState(0);

  const handleVisit = () => {
    viewTool(tool.id);
    window.open(tool.url, "_blank");
    setTimeout(() => setShowRating(true), 500);
  };

  const handleRate = (r: number) => {
    rateTool(tool.id, r);
    setShowRating(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative rounded-2xl border border-border bg-card p-4 shadow-card hover:shadow-elevated transition-all duration-300 hover:-translate-y-1"
    >
      {rank && (
        <div className="absolute -top-2.5 -left-2.5 w-8 h-8 rounded-lg gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground shadow-glow">
          #{rank}
        </div>
      )}

      {tool.imageUrl && (
        <div className="mb-3 rounded-xl overflow-hidden border border-border">
          <img src={tool.imageUrl} alt={tool.name} className="w-full h-28 object-cover" />
        </div>
      )}

      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{tool.emoji}</span>
          <div>
            <h3 className="font-display font-semibold text-sm">{tool.name}</h3>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
              {tool.category}
            </span>
          </div>
        </div>
        <button
          onClick={() => toggleFavorite(tool.id)}
          className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
        >
          <Heart
            size={16}
            className={tool.isFavorite ? "fill-destructive text-destructive" : "text-muted-foreground"}
          />
        </button>
      </div>

      <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{tool.description}</p>

      <div className="flex items-center gap-3 text-[11px] text-muted-foreground mb-3">
        <span className="flex items-center gap-1">
          <Star size={12} className="text-warning fill-warning" /> {tool.rating > 0 ? tool.rating.toFixed(1) : "New"}
        </span>
        <span className="flex items-center gap-1">
          <Eye size={12} /> {tool.views.toLocaleString()}
        </span>
      </div>

      <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-3">
        <span>By <strong className="text-foreground/80">{tool.author}</strong></span>
        <span>Added by <strong className="text-foreground/80">{tool.addedBy}</strong></span>
      </div>

      <button
        onClick={handleVisit}
        className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity"
      >
        Visit <ExternalLink size={12} />
      </button>

      {showRating && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute inset-0 bg-card/95 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center p-4"
        >
          <p className="text-sm font-medium mb-2">How was {tool.name}?</p>
          <div className="flex gap-1 mb-3">
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                onMouseEnter={() => setHoverStar(s)}
                onMouseLeave={() => setHoverStar(0)}
                onClick={() => handleRate(s)}
              >
                <Star
                  size={24}
                  className={`transition-colors ${
                    s <= hoverStar ? "fill-warning text-warning" : "text-muted-foreground"
                  }`}
                />
              </button>
            ))}
          </div>
          <button onClick={() => setShowRating(false)} className="text-xs text-muted-foreground hover:text-foreground">
            Skip
          </button>
        </motion.div>
      )}
    </motion.div>
  );
}
