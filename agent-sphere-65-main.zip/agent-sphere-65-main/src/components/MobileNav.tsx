import { NavLink } from "react-router-dom";
import { Home, TrendingUp, Grid3X3, Heart, StickyNote, Users, User } from "lucide-react";

const items = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/emerging", icon: TrendingUp, label: "Emerging" },
  { to: "/categories", icon: Grid3X3, label: "Categories" },
  { to: "/favorites", icon: Heart, label: "Favorites" },
  { to: "/notes", icon: StickyNote, label: "Notes" },
  { to: "/developers", icon: Users, label: "Devs" },
  { to: "/profile", icon: User, label: "Profile" },
];

export default function MobileNav() {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 backdrop-blur-xl">
      <div className="flex justify-around py-2">
        {items.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex flex-col items-center gap-0.5 px-2 py-1 text-[10px] font-medium transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
