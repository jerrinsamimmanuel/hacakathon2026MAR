import { NavLink as RouterNavLink, useLocation } from "react-router-dom";
import { Home, TrendingUp, Grid3X3, Heart, StickyNote, Users, User } from "lucide-react";
import { motion } from "framer-motion";

const navItems = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/emerging", icon: TrendingUp, label: "Emerging AI" },
  { to: "/categories", icon: Grid3X3, label: "Categories" },
  { to: "/favorites", icon: Heart, label: "Favorites" },
  { to: "/notes", icon: StickyNote, label: "Notes" },
  { to: "/developers", icon: Users, label: "Developers" },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <aside className="hidden md:flex flex-col w-64 border-r border-border bg-sidebar h-[calc(100vh-57px)] sticky top-[57px]">
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map(({ to, icon: Icon, label }) => {
          const active = location.pathname === to;
          return (
            <RouterNavLink
              key={to}
              to={to}
              className="relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors"
            >
              {active && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute inset-0 rounded-xl bg-sidebar-accent"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
                />
              )}
              <span className={`relative z-10 ${active ? "text-sidebar-accent-foreground" : "text-sidebar-foreground/70 hover:text-sidebar-foreground"}`}>
                <Icon size={18} />
              </span>
              <span className={`relative z-10 ${active ? "text-sidebar-accent-foreground" : "text-sidebar-foreground/70 hover:text-sidebar-foreground"}`}>
                {label}
              </span>
            </RouterNavLink>
          );
        })}
      </nav>
      <div className="p-3 border-t border-border">
        <RouterNavLink
          to="/profile"
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
        >
          <User size={18} />
          <span>Profile</span>
        </RouterNavLink>
      </div>
    </aside>
  );
}
