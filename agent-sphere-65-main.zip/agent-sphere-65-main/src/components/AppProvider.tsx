import { useState, useCallback, useEffect, ReactNode } from "react";
import { AppContext, AppState } from "@/lib/store";
import { AITool, SEMANTIC_KEYWORDS } from "@/lib/types";
import { seedTools } from "@/lib/seed-data";

const STORAGE_KEY = "ai-marketplace";

function loadState(): AppState {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...parsed, searchQuery: "" };
    }
  } catch {}
  return { tools: seedTools, searchQuery: "", isDark: false };
}

function saveState(state: AppState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ tools: state.tools, isDark: state.isDark }));
}

export default function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(loadState);

  useEffect(() => {
    saveState(state);
    document.documentElement.classList.toggle("dark", state.isDark);
  }, [state]);

  const toggleFavorite = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      tools: s.tools.map((t) => (t.id === id ? { ...t, isFavorite: !t.isFavorite } : t)),
    }));
  }, []);

  const addTool = useCallback((tool: Omit<AITool, "id" | "rating" | "totalRatings" | "views" | "isFavorite" | "createdAt">) => {
    setState((s) => ({
      ...s,
      tools: [
        ...s.tools,
        {
          ...tool,
          id: Date.now().toString(),
          rating: 0,
          totalRatings: 0,
          views: 0,
          isFavorite: false,
          createdAt: new Date().toISOString().split("T")[0],
          imageUrl: tool.imageUrl,
        },
      ],
    }));
  }, []);

  const rateTool = useCallback((id: string, rating: number) => {
    setState((s) => ({
      ...s,
      tools: s.tools.map((t) => {
        if (t.id !== id) return t;
        const newTotal = t.totalRatings + 1;
        const newRating = (t.rating * t.totalRatings + rating) / newTotal;
        return { ...t, rating: Math.round(newRating * 10) / 10, totalRatings: newTotal };
      }),
    }));
  }, []);

  const viewTool = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      tools: s.tools.map((t) => (t.id === id ? { ...t, views: t.views + 1 } : t)),
    }));
  }, []);

  const setSearchQuery = useCallback((q: string) => {
    setState((s) => ({ ...s, searchQuery: q }));
  }, []);

  const toggleDarkMode = useCallback(() => {
    setState((s) => ({ ...s, isDark: !s.isDark }));
  }, []);

  const getFilteredTools = useCallback(
    (query?: string) => {
      const q = (query ?? state.searchQuery).toLowerCase().trim();
      if (!q) return state.tools;

      // Build expanded search terms from semantic keywords
      const words = q.split(/\s+/);
      const expandedTerms = new Set<string>([q]);
      words.forEach((word) => {
        expandedTerms.add(word);
        const synonyms = SEMANTIC_KEYWORDS[word];
        if (synonyms) {
          synonyms.forEach((s) => expandedTerms.add(s));
        }
      });

      const termsArray = Array.from(expandedTerms);
      return state.tools.filter((t) => {
        const searchable = `${t.name} ${t.description} ${t.category} ${t.url} ${t.author} ${t.addedBy}`.toLowerCase();
        return termsArray.some((term) => searchable.includes(term));
      });
    },
    [state.tools, state.searchQuery]
  );

  return (
    <AppContext.Provider
      value={{ state, toggleFavorite, addTool, rateTool, viewTool, setSearchQuery, toggleDarkMode, getFilteredTools }}
    >
      {children}
    </AppContext.Provider>
  );
}
