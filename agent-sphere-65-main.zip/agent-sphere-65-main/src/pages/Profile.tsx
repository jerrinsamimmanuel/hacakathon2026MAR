import { useApp } from "@/lib/store";
import { Star, Eye, Heart, Layers } from "lucide-react";

export default function ProfilePage() {
  const { state } = useApp();
  const myTools = state.tools.filter((t) => t.addedBy === "You");
  const favorites = state.tools.filter((t) => t.isFavorite);

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-2xl gradient-hero flex items-center justify-center text-3xl text-primary-foreground font-bold">
          U
        </div>
        <div>
          <h1 className="text-2xl font-display font-bold">Your Profile</h1>
          <p className="text-sm text-muted-foreground">Community contributor</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Layers} label="Tools Added" value={myTools.length} />
        <StatCard icon={Heart} label="Favorites" value={favorites.length} />
        <StatCard icon={Eye} label="Total Views" value={myTools.reduce((s, t) => s + t.views, 0)} />
        <StatCard icon={Star} label="Avg Rating" value={myTools.length ? (myTools.reduce((s, t) => s + t.rating, 0) / myTools.length).toFixed(1) : "N/A"} />
      </div>

      {myTools.length > 0 && (
        <section>
          <h2 className="text-lg font-display font-semibold mb-3">Your Contributions</h2>
          <div className="space-y-3">
            {myTools.map((t) => (
              <div key={t.id} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{t.emoji}</span>
                  <div>
                    <h3 className="font-semibold text-sm">{t.name}</h3>
                    <span className="text-[10px] text-primary">{t.category}</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{t.description}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {favorites.length > 0 && (
        <section>
          <h2 className="text-lg font-display font-semibold mb-3">Your Favorites</h2>
          <div className="flex flex-wrap gap-2">
            {favorites.map((t) => (
              <span key={t.id} className="px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive text-xs font-medium">
                {t.emoji} {t.name}
              </span>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: string | number }) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <Icon size={18} className="text-primary mb-2" />
      <p className="text-xl font-bold font-display">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
