import { useApp } from "@/lib/store";
import AIToolCard from "@/components/AIToolCard";

export default function FavoritesPage() {
  const { state } = useApp();
  const favorites = state.tools.filter((t) => t.isFavorite);

  return (
    <div className="animate-fade-in space-y-6">
      <div>
        <h1 className="text-2xl font-display font-bold">❤️ Favorites</h1>
        <p className="text-sm text-muted-foreground">{favorites.length} saved tools</p>
      </div>

      {favorites.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {favorites.map((t) => (
            <AIToolCard key={t.id} tool={t} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 text-muted-foreground">
          <p className="text-5xl mb-3">💜</p>
          <p className="font-medium">No favorites yet</p>
          <p className="text-sm mt-1">Click the heart icon on any AI tool to save it here</p>
        </div>
      )}
    </div>
  );
}
