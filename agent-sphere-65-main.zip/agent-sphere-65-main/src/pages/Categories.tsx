import { useState } from "react";
import { useApp } from "@/lib/store";
import { ALL_CATEGORIES, CATEGORY_INFO, AICategory } from "@/lib/types";
import AIToolCard from "@/components/AIToolCard";
import { motion, AnimatePresence } from "framer-motion";

export default function CategoriesPage() {
  const { getFilteredTools, state } = useApp();
  const [selected, setSelected] = useState<AICategory | null>(null);
  const tools = getFilteredTools();

  const filtered = selected ? tools.filter((t) => t.category === selected) : tools;

  return (
    <div className="animate-fade-in space-y-6">
      <div>
        <h1 className="text-2xl font-display font-bold">📂 Categories</h1>
        <p className="text-sm text-muted-foreground">Browse AI tools by category</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        <button
          onClick={() => setSelected(null)}
          className={`p-3 rounded-xl text-left transition-all ${
            !selected ? "gradient-primary text-primary-foreground shadow-glow" : "bg-card border border-border hover:border-primary/50"
          }`}
        >
          <span className="text-xl">🌐</span>
          <p className="text-sm font-semibold mt-1">All</p>
          <p className="text-[10px] opacity-80">{tools.length} tools</p>
        </button>
        {ALL_CATEGORIES.map((cat) => {
          const info = CATEGORY_INFO[cat];
          const count = tools.filter((t) => t.category === cat).length;
          const active = selected === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelected(active ? null : cat)}
              className={`p-3 rounded-xl text-left transition-all ${
                active ? "gradient-primary text-primary-foreground shadow-glow" : "bg-card border border-border hover:border-primary/50"
              }`}
            >
              <span className="text-xl">{info.emoji}</span>
              <p className="text-sm font-semibold mt-1">{cat}</p>
              <p className="text-[10px] opacity-80">{count} tools</p>
            </button>
          );
        })}
      </div>

      {state.searchQuery && (
        <div className="rounded-xl bg-primary/10 border border-primary/20 px-4 py-2 text-sm">
          Searching: "<strong>{state.searchQuery}</strong>"
        </div>
      )}

      <AnimatePresence mode="wait">
        <motion.div
          key={selected || "all"}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {filtered.map((t) => (
            <AIToolCard key={t.id} tool={t} />
          ))}
        </motion.div>
      </AnimatePresence>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <p className="text-4xl mb-2">📭</p>
          <p>No tools in this category yet.</p>
        </div>
      )}
    </div>
  );
}
