import { useState } from "react";
import { useApp } from "@/lib/store";
import { ALL_CATEGORIES, AICategory } from "@/lib/types";
import { Briefcase, UserCircle, Star, Eye, Plus, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function DevelopersPage() {
  const { state, addTool } = useApp();
  const tools = state.tools;
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", url: "", description: "", category: "Coding" as AICategory, author: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.url || !form.description) return;
    addTool({ name: form.name, url: form.url, description: form.description, category: form.category, author: form.author || "Unknown", addedBy: "Developer", emoji: "🤖" });
    setForm({ name: "", url: "", description: "", category: "Coding", author: "" });
    setShowForm(false);
  };

  // Group by author (creators)
  const creatorMap = new Map<string, { tools: typeof tools; views: number; avgRating: number }>();
  tools.forEach((t) => {
    const entry = creatorMap.get(t.author) || { tools: [], views: 0, avgRating: 0 };
    entry.tools.push(t);
    entry.views += t.views;
    creatorMap.set(t.author, entry);
  });
  creatorMap.forEach((v) => {
    const rated = v.tools.filter((t) => t.rating > 0);
    v.avgRating = rated.length ? rated.reduce((s, t) => s + t.rating, 0) / rated.length : 0;
  });

  // Group by addedBy (contributors)
  const contributorMap = new Map<string, { tools: typeof tools; views: number }>();
  tools.forEach((t) => {
    const entry = contributorMap.get(t.addedBy) || { tools: [], views: 0 };
    entry.tools.push(t);
    entry.views += t.views;
    contributorMap.set(t.addedBy, entry);
  });

  const creators = Array.from(creatorMap.entries()).sort((a, b) => b[1].views - a[1].views);
  const contributors = Array.from(contributorMap.entries()).sort((a, b) => b[1].tools.length - a[1].tools.length);

  return (
    <div className="animate-fade-in space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold">👥 Developers</h1>
          <p className="text-sm text-muted-foreground">AI tool creators and community contributors</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity"
        >
          {showForm ? <X size={16} /> : <Plus size={16} />}
          {showForm ? "Cancel" : "Add AI Tool"}
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="bg-card border border-border rounded-2xl p-5 space-y-4 overflow-hidden"
          >
            <h3 className="font-display font-semibold">Submit Your AI Tool</h3>
            <p className="text-xs text-muted-foreground">Your tool will appear in the Emerging AI section</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input placeholder="AI Tool Name *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" required />
              <input placeholder="URL (https://...) *" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" required />
              <input placeholder="Your Name / Company" value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as AICategory })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
                {ALL_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <textarea placeholder="Describe your AI tool *" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="w-full px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none" required />
            <button type="submit" className="px-6 py-2.5 rounded-xl text-sm font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity">
              Submit to Emerging AI
            </button>
          </motion.form>
        )}
      </AnimatePresence>

      <section>
        <h2 className="text-lg font-display font-semibold mb-4 flex items-center gap-2">
          <Briefcase size={18} className="text-primary" /> AI Tool Creators
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {creators.map(([name, data]) => (
            <div key={name} className="bg-card border border-border rounded-2xl p-4 hover:shadow-elevated transition-shadow">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
                  {name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-display font-semibold text-sm">{name}</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">AI Creator</span>
                </div>
              </div>
              <div className="flex gap-4 text-xs text-muted-foreground">
                <span>{data.tools.length} tools</span>
                <span className="flex items-center gap-1"><Eye size={12} /> {data.views.toLocaleString()}</span>
                <span className="flex items-center gap-1"><Star size={12} className="text-warning" /> {data.avgRating.toFixed(1)}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-lg font-display font-semibold mb-4 flex items-center gap-2">
          <UserCircle size={18} className="text-success" /> Community Contributors
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {contributors.map(([name, data]) => (
            <div key={name} className="bg-card border border-border rounded-2xl p-4 hover:shadow-elevated transition-shadow">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl gradient-accent flex items-center justify-center text-primary-foreground font-bold text-sm">
                  {name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-display font-semibold text-sm">{name}</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-success/10 text-success font-medium">
                    {name === "You" ? "Your Profile" : "Contributor"}
                  </span>
                </div>
              </div>
              <div className="flex gap-4 text-xs text-muted-foreground">
                <span>{data.tools.length} shared</span>
                <span className="flex items-center gap-1"><Eye size={12} /> {data.views.toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
