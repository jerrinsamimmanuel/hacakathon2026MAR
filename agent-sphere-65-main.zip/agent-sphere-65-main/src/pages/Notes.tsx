import { useState } from "react";
import { useApp } from "@/lib/store";
import { ALL_CATEGORIES, AICategory } from "@/lib/types";
import { Plus, X, Briefcase, UserCircle, Image } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function NotesPage() {
  const { state, addTool, getFilteredTools } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", url: "", description: "", category: "Writing" as AICategory, author: "", addedBy: "You", imageUrl: "" });

  const tools = getFilteredTools();
  const communityNotes = tools.filter((t) => t.addedBy !== "Admin");
  const adminNotes = tools.filter((t) => t.addedBy === "Admin");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.url || !form.description) return;
    addTool({ name: form.name, url: form.url, description: form.description, category: form.category, author: form.author || "Unknown", addedBy: form.addedBy || "Anonymous", emoji: "🤖", imageUrl: form.imageUrl || undefined });
    setForm({ name: "", url: "", description: "", category: "Writing", author: "", addedBy: "You", imageUrl: "" });
    setShowForm(false);
  };

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold">📝 Notes</h1>
          <p className="text-sm text-muted-foreground">Add & browse AI tool notes from the community</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity"
        >
          {showForm ? <X size={16} /> : <Plus size={16} />}
          {showForm ? "Cancel" : "Add New AI Tool"}
        </button>
      </div>

      {state.searchQuery && (
        <div className="rounded-xl bg-primary/10 border border-primary/20 px-4 py-2 text-sm">
          Searching notes: "<strong>{state.searchQuery}</strong>" — {tools.length} results
        </div>
      )}

      <AnimatePresence>
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="bg-card border border-border rounded-2xl p-5 space-y-4 overflow-hidden"
          >
            <h3 className="font-display font-semibold">Add a New AI Tool</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input placeholder="AI Tool Name *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" required />
              <input placeholder="URL (https://...) *" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" required />
              <input placeholder="Author / Creator (who built it)" value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as AICategory })} className="px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
                {ALL_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-3">
              <Image size={16} className="text-muted-foreground" />
              <input placeholder="Image URL (thumbnail/screenshot)" value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} className="flex-1 px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>
            <textarea placeholder="Description / Notes *" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="w-full px-4 py-2.5 rounded-xl bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none" required />
            <button type="submit" className="px-6 py-2.5 rounded-xl text-sm font-medium gradient-primary text-primary-foreground hover:opacity-90 transition-opacity">
              Submit Tool
            </button>
          </motion.form>
        )}
      </AnimatePresence>

      {communityNotes.length > 0 && (
        <section>
          <h2 className="text-lg font-display font-semibold mb-3 flex items-center gap-2">
            <UserCircle size={18} className="text-success" /> Community Added
          </h2>
          <div className="space-y-3">
            {communityNotes.map((t) => (
              <NoteCard key={t.id} tool={t} />
            ))}
          </div>
        </section>
      )}

      <section>
        <h2 className="text-lg font-display font-semibold mb-3 flex items-center gap-2">
          <Briefcase size={18} className="text-primary" /> All Notes
        </h2>
        <div className="space-y-3">
          {(communityNotes.length > 0 ? adminNotes : tools).map((t) => (
            <NoteCard key={t.id} tool={t} />
          ))}
        </div>
      </section>
    </div>
  );
}

function NoteCard({ tool }: { tool: import("@/lib/types").AITool }) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 hover:shadow-card transition-shadow">
      <div className="flex items-start gap-4">
        {tool.imageUrl && (
          <img src={tool.imageUrl} alt={tool.name} className="w-16 h-16 rounded-lg object-cover flex-shrink-0 border border-border" />
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">{tool.emoji}</span>
              <div>
                <h3 className="font-semibold text-sm">{tool.name}</h3>
                <span className="text-[10px] text-primary font-medium">{tool.category}</span>
              </div>
            </div>
            <a href={tool.url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline truncate max-w-[200px]">{tool.url}</a>
          </div>
          <p className="text-xs text-muted-foreground mt-2">{tool.description}</p>
          <div className="flex gap-4 mt-2 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1"><Briefcase size={10} className="text-primary" /> Author: <strong>{tool.author}</strong></span>
            <span className="flex items-center gap-1"><UserCircle size={10} className="text-success" /> Added by: <strong>{tool.addedBy}</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
}
