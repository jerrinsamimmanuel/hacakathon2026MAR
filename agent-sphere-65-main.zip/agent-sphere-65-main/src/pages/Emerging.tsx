import { useState } from "react";
import { useApp } from "@/lib/store";
import AIToolCard from "@/components/AIToolCard";

type SortBy = "rating" | "views" | "recent";

export default function EmergingPage() {
  const { getFilteredTools, state } = useApp();
  const [sortBy, setSortBy] = useState<SortBy>("rating");

  const tools = getFilteredTools();
  const sorted = [...tools].sort((a, b) => {
    if (sortBy === "rating") return b.rating - a.rating;
    if (sortBy === "views") return b.views - a.views;
    return b.createdAt.localeCompare(a.createdAt);
  });

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold">🔥 Emerging AI</h1>
          <p className="text-sm text-muted-foreground">Ranked by community ratings and popularity</p>
        </div>
        <div className="flex gap-2">
          {(["rating", "views", "recent"] as SortBy[]).map((s) => (
            <button
              key={s}
              onClick={() => setSortBy(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                sortBy === s ? "gradient-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-accent/20"
              }`}
            >
              {s === "rating" ? "⭐ Rating" : s === "views" ? "👀 Views" : "🆕 Recent"}
            </button>
          ))}
        </div>
      </div>

      {state.searchQuery && (
        <div className="rounded-xl bg-primary/10 border border-primary/20 px-4 py-2 text-sm">
          Searching: "<strong>{state.searchQuery}</strong>" — {sorted.length} results
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {sorted.map((t, i) => (
          <AIToolCard key={t.id} tool={t} rank={sortBy === "rating" ? i + 1 : undefined} />
        ))}
      </div>

      {sorted.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <p className="text-4xl mb-2">🔍</p>
          <p>No tools found matching your search.</p>
        </div>
      )}
    </div>
  );
}
