import { useApp } from "@/lib/store";
import AIToolCard from "@/components/AIToolCard";
import { TrendingUp, Star } from "lucide-react";

export default function HomePage() {
  const { state, getFilteredTools } = useApp();
  const tools = getFilteredTools();

  const topRated = [...tools].sort((a, b) => b.rating - a.rating).slice(0, 4);
  const trending = [...tools].sort((a, b) => b.views - a.views).slice(0, 4);
  const recent = [...tools].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 4);


  return (
    <div className="animate-fade-in space-y-8">
      <div>
        <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
          Discover the Best <span className="text-gradient">AI Tools</span>
        </h1>
        <p className="text-muted-foreground">Explore, rate, and share AI tools across categories</p>
      </div>


      {state.searchQuery && (
        <div className="rounded-xl bg-primary/10 border border-primary/20 px-4 py-2 text-sm">
          Showing results for "<strong>{state.searchQuery}</strong>" — {tools.length} found
        </div>
      )}

      <section>
        <h2 className="text-xl font-display font-semibold mb-4 flex items-center gap-2">
          <Star size={20} className="text-warning" /> Top Rated
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {topRated.map((t, i) => (
            <AIToolCard key={t.id} tool={t} rank={i + 1} />
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-display font-semibold mb-4 flex items-center gap-2">
          <TrendingUp size={20} className="text-success" /> Trending
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {trending.map((t) => (
            <AIToolCard key={t.id} tool={t} />
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-display font-semibold mb-4">🆕 Recently Added</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {recent.map((t) => (
            <AIToolCard key={t.id} tool={t} />
          ))}
        </div>
      </section>
    </div>
  );
}
